<?php

return [
    'email' => "sopnev@mail.ru",
    'name' => 'sopnev'
];
